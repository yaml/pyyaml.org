import yaml, string

####### RUNNING YAML AGAINST THE README AND CHANGELOG

readme = yaml.loadFile("README")
print "README"
for item in readme.next():
    print item
print "\n\nCONTRIBUTORS"
for person in readme.next()['contributors']:
    print "===%s===" % person['who']
    print person['why?']
    print
print "\n\n"
print "CHANGELOG:\n"
print list(yaml.loadFile("CHANGELOG"))
print "\n\n"

######## USING YAML INSIDE YOUR PROGRAM

testData = \
"""
program: PyYaml
author: Steve Howell
---
shopping list:
 - apple
 - banana
todo:
 - eat more fruit:
     - especially bananas!
     - good for you
 - write a better demo
"""

print "YAML INSIDE YOUR PROGRAM"
for x in yaml.load(testData):
   print repr(x)
print "\n\n"


######### YPATH STUFF

try:
    print "YPATH EXPERIMENTATION"
    data = yaml.load(testData)
    print yaml.ypath("/author",data.next()).next()
    print yaml.dump(yaml.ypath("/todo/0",data.next()).next())
except NotImplementedError:
    print "Experimental YPATH requires Python 2.2"

######### YAML DUMPER 

class Person:
    def __init__(self, fname, lname, salary, children):
        self.fname = fname
        self.lname = lname
        self.salary = salary
        self.children = children
        # private variables
        self._fullname = fname + ' ' + lname
        if salary:
            self._sal_per_month = salary / 12.0
        self._num_children = len(children)
    def to_yaml(self):
        return ({
            'first name': self.fname,
            'last name':  self.lname,
            'salary':     self.salary
        }, '!!Person')

mrBarson = Person('Foo', 'Barson', 20, ['ex', 'theomatic'])
mrDoe = Person('John', 'Doe', None, [])
print yaml.dump([mrBarson, mrDoe])

print "\n\nANOTHER WAY TO STDOUT:\n"
import sys
yaml.dumpToFile(sys.stdout, [mrBarson, mrDoe])

print "\n\nDUMP MULTIPLE DOCS TO A FILE:\n"
file = open('DEMO_OUTPUT.TXT', 'w')
yaml.dumpToFile(file, 
    {'source': "Demo output from demo.py"},
    [
        'apple',
        'banana',
    ],
    'Third document'      
)
file.close()


