import re
import string

def convertImplicit(val):
    if val == '~':
        return None
    if val[0] == "'" and val[-1] == "'":
        val = val[1:-1]
        return string.replace(val, "''", "\'")
    if val[0] == '"' and val[-1] == '"':
        unescapedStr = eval (val)
        return unescapedStr
    return val


