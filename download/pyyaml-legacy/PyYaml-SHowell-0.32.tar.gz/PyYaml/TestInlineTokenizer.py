import YamlTest
from test import assertEquals
from yaml.load import *


class Test(YamlTest.YamlTest):
    def testSimple(self):
        tokenizer = InlineTokenizer('[ foo, bar ]')
        assertEquals(tokenizer.next(), '[')
        assertEquals(tokenizer.next(), 'foo')
        assertEquals(tokenizer.next(), 'bar')
        assertEquals(tokenizer.next(), ']')

    def testSimpleHash(self):
        tokenizer = InlineTokenizer('{ foo: bar }')
        assertEquals(tokenizer.next(), '{')
        assertEquals(tokenizer.next(), 'foo: bar') # might change
        assertEquals(tokenizer.next(), '}')

if __name__ == '__main__':
    import unittest
    unittest.main()
