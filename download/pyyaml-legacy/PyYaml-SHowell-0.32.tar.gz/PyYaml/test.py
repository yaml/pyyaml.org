def assertEquals(first, second, msg=''):
    if first != second:
        raise AssertionError, \
              (msg + "\n%s !=\n%s" % (`first`, `second`))

def assertError(func, expectedError):
    raised = 1
    try:
        func()
        raised = 0
    except Exception, e:
        assertEquals(str(e), expectedError)
    except:
        raise "Unexpected exception"
    if raised == 0:
        raise "Never threw exception"


