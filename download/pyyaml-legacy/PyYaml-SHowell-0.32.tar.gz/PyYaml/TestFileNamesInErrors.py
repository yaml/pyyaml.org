#!/usr/bin/env python
import yaml, re
try:
    print yaml.loadFile('TestFileNamesInErrors.py').next()
    raise "YAML actually parsed this file, uh oh!"
except Exception, e:
    if not re.search('TestFileNamesInErrors\.py', str(e)):
        raise 'YAML not reporting filename properly ("%s")' % e
