import profile
import pstats
import yaml
import glob

def loadAllFiles():
    testFiles = glob.glob('TestingSuite/*.yml')
    for file in testFiles:
        docs = yaml.loadFile(file)
        for doc in docs:
            exercise(doc)

def exercise(doc):                
    if 'python' in doc:
        if 'yaml' in doc:
            for subDoc in yaml.load(doc['yaml']):
                pass
print dir(profile)
profile.run('loadAllFiles()', 'profileResults')

p = pstats.Stats('profileResults')
file = open("profile.out", "w")
p.sort_stats('time').print_stats(25)
