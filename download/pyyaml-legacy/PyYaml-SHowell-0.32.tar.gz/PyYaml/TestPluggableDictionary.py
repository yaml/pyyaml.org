import yaml
from yaml.ordered_dict import OrderedDict
from yaml.redump import redump
from test import assertEquals

stream = """\
---
zzz: 0
yyy: 1
xxx: 2
alpha: 3
---
-
    foo: 1
    bar: 2
-
    z: 1
    y: 2
"""

my_dict = yaml.loadOrdered(stream).next()
assertEquals(my_dict.keys(), ['zzz', 'yyy', 'xxx', 'alpha'])

assertEquals(redump(stream), stream)
   
