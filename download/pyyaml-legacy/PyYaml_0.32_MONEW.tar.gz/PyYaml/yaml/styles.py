#!/usr/bin/env python
"""Styles for the emitter.
"""

STR_NORMAL = ''
STR_SQUOTE = "'"
STR_DQUOTE = '"'
STR_LITERAL = '|'
STR_FLOW = '>'
STR_FLOW_NL = '>-'

SEQ_BLOCK = SEQ_NORMAL = '-'
SEQ_COMPACT = '[]'
SEQ_NORMAL = SEQ_BLOCK

MAP_BLOCK = ':'
MAP_COMPACT = '{}'
MAP_NORMAL = MAP_BLOCK


# vim: sw=4 ts=4 expandtab ai
