#!/usr/bin/env python
"""DumbEmitter -- chatty debugging emitter.

"""
from yaml.emitters.Emitter import Emitter

class DumbEmitter(Emitter):
    def __init__(self, ostream):
        print "DumbEmitter: __init__(ostream=%r)" % ostream

    # Parser/Emitter API methods.
    def begin_document(self, directives=''):
        print "DumbEmitter: begin_document(directives=%r)" % directives

    def end_document(self):
        print "DumbEmitter: end_document()"

    def complete_scalar(self, node):
        print "DumbEmitter: complete_scalar(node=%r)" % node

    def begin_sequence(self, node):
        print "DumbEmitter: begin_sequence(node=%r)" % node

    def begin_mapping(self, node):
        print "DumbEmitter: begin_mapping(node=%r)" % node

    def end_sequence(self):
        print "DumbEmitter: end_sequence()"

    def end_mapping(self):
        print "DumbEmitter: end_mapping()"

    def begin_scalar(self, node):
        print "DumbEmitter: begin_scalar(node=%r)" % node

    def append_scalar(self, value):
        print "DumbEmitter: append_scalar(value=%r)" % value

    def end_scalar(self):
        print "DumbEmitter: end_scalar()"


# vim: sw=4 ts=4 expandtab ai
