#!/usr/bin/env python
"""Emitter -- default emitter and base class.

Subclasses can override .scalarStyle(), .seqStyle() and .mapStyle() to
indicate how to write particular values.  Note: this may be superceded
by filters or schemas.

XXX How to handle map in seq?
"""
from yaml.styles import STR_NORMAL, SEQ_NORMAL, MAP_NORMAL

class Emitter:
    writeDotsAfterEveryDocument = False
    writeDotsAfterLastDocument = False
    filters = []

    def __init__(self, ostream):
        self.ostream = ostream
        self.collectionStack = []  # The pending (unfinished) collections.
        self.scalarNode = None    # Node of the pending scalar, or None.
        self.scalarChunks = None  # Chunks of the pending scalar, or None.
        self.indentLevel = 0

    def scalarStyle(self, scalar):  return STR_NORMAL
    def SeqStyle(self, seq):  return SEQ_NORMAL
    def mapStyle(self, map_):  return MAP_NORMAL

    def writeDots(self):
        self.ostream.write("...\n")

    def close(self):
        if self.writeDotsAfterLastDocument and not \
            self.writeDotsAfterEveryDocument:
            self.writeDots()

    # Parser/Emitter API methods.
    def begin_document(self, directives=''):
        self.ostream.write("--- %s\n" % directives)

    def end_document(self):
        if self.writeDotsAfterEveryDocument:
            self.writeDots()

    def complete_scalar(self, node):
        if self.collectionStack:
            self.collectionStack[-1].value.append(node)
        else:
            self.ostream.write(node.value)
            # XXX Should honor node.style.

    def begin_sequence(self, node):
        node.value = []
        self.collectionStack.append([node])

    def begin_mapping(self, node):
        node.value = []
        self.collectionStack.append([node])

    def end_sequence(self):
        collection = self.collectionStack.pop()
        collectionNode = collection[0]
        for node in collection[1:]:
            s = self.complete_scalar(node)
            self.ostream.write("- " + s)

    def end_mapping(self):
        collection = self.collectionStack.pop()
        assert len(collection) % 2 == 1 # It better be odd.
        collectionNode = collection[0]
        for i in range(1, len(collection), 2):
            key = collection[i]
            value = collection[i + 1]
            k = self.complete_scalar(key)
            v = self.complete_scalar(value)
            self.ostream.write("%s: %s" % (k, v))

    def begin_scalar(self, node):
        self.scalarNode = node
        self.scalarChunks = []

    def append_scalar(self, value):
        self.scalarChunks.append(value)

    def end_scalar(self):
        node = self.scalarNode
        node.value = ''.join(self.scalarChunks)
        self.complete_scalar(node)
        self.scalarNode = None
        self.scalarChunks = None

# vim: sw=4 ts=4 expandtab ai
