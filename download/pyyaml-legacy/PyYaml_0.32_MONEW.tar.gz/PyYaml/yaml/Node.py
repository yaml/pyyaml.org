#!/usr/bin/env python
"""A YAML node is a value with its type information.

.value is a string, list, or list of pairs.
.style is a constant from yaml.styles
.key is the corresponding key if this is a mapping value, or None otherwise.
    (Some filters want to know what the key is.)
.native is the native object this represents, or None if unknown.  This
    is merely for the user's convenience and for error messages.
"""

SCALAR = 'scalar';  SEQ = 'seq';  MAP = 'map'

class Node:
    def __init__(self):
        self.nodeType = None  # SCALAR, SEQ, MAP, or None for unknown.
        self.anchor = None
        self.typeUri = ''
        self.format = None
        self.style = None
        self.value = None
        self.attribs = {}
        self.key = None
        self.native = None

class ScalarNode(Node):
    nodeType = 'scalar'

class SeqNode(Node):
    nodeType = 'seq'

class MapNode(Node):
    nodeType = 'map'


# vim: sw=4 ts=4 expandtab ai
