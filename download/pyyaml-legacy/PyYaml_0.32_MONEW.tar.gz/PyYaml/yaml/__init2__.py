#!/usr/bin/env python
"""PyYAML top-level package module.  PyYAML's basic usage:

import yaml
yaml.load(myString)
    # Parses YAML from a string and returns an *iterator* of objects.
yaml.loadFile(istream)
    # Same but 'istream' is a file name or file-like object.
myString = yaml.dump(*objects)
    # Each object becomes a document in the resulting YAML string.
yaml.dumpFile(ostream, *objects)
    # same but 'ostream' is a file name or file-like object.

# Module attributes allow you to override the helper classes.
yaml.parser = MyParser    # Default yaml.Parser.Parser
yaml.loader = MyLoader    # Default yaml.Loader.Loader
yaml.dumper = MyDumper    # Default yaml.Dumper.Dumper
yaml.emitter = MyEmitter  # Default yaml.Emitter.Emitter

# You can also set attributes and options in the helper classes.
yaml.loader.scalarFilters = [MyTypes, yaml.Filters.ExplicitTypes,
    yaml.Filters.ImplicitTypes]
# also yaml.loader.seqFilters, yaml.loader.mapFilters
yaml.emitter.writeDotsAfterEveryDocument = True

# XXX Should .filters contain classes or instances?

For anything more complicated, or if you have to have different
behaviors active simultaneously, read the source below to see how to
invoke the helper classes directly.
"""

from cStringIO import StringIO
from yaml.parsers.Parser import Parser
from yaml.loaders.Loader import Loader
from yaml.dumpers.Dumper import Dumper
from yaml.emitters.Emitter import Emitter
#from yaml.filters.ExplicitTypes import ExplicitTypes
#from yaml.filters.ImplicitTypes import ImplicitTypes

# Helper classes.
parser = Parser
loader = Loader
dumper = Dumper
emitter = Emitter


def load(s):
    istream = StringIO(s)
    return loadFile(istream, s)

def dump(*objects):
    ostream = StringIO()
    return dumpFile(ostream, *objects)

def _universalOpener(stream_or_filename, mode):
    try:
        stream_or_filename + ''
    except:  # It's a stream.
        stream = stream_or_filename
        shouldClose = False
    else:  # It's a filename.
        stream = file(stream_or_filename, mode)
        shouldClose = True
    return stream, shouldClose


def loadFile(istream_or_filename, s):
    istream, shouldClose = _universalOpener(istream_or_filename, 'r')
        # XXX When Python 2.3 is standard use mode 'rU' for universal
        # newline support.
    p = parser(istream)
    l = loader(p)
    #try:
    #    yield l.load_one_document()
    ret = l.load()   # An iterator of objects.
    if shouldClose:
        istream.close()
    return ret


def dumpFile(ostream_or_filename, *objects):
    ostream, shouldClose = _universalOpener(ostream_or_filename, 'w')
    e = emitter(ostream)
    d = dumper(e)
    for o in objects:
        d.dump_one_document(o)
    if shouldClose:
        ostream.close()
    return None   # The result data is in the stream.
	

# vim: sw=4 ts=4 expandtab ai
