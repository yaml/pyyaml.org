#!/usr/bin/python
from yaml.Node import Node

class Filter:
    def load(self, node):
        """Modify the node in place if appropriate.  Return True to indicate
           this is the last filter, or False to allow later filters in the
           chain to operate.
        """
        raise NotImplementedError

    def dump(self, node):
        """Modify the node in place if appropriate.  Return True to indicate
           this is the last filter, or False to allow later filters in the
           chain to operate.
        """
        raise NotImplementedError


class ScalarFilter(Filter):
    pass

class SeqFilter(Filter):
    pass

class MapFilter(Filter):
    pass


class AllScalarsAreStringsFilter(ScalarFilter):
    def load(self, node):
        node.value = str(node.value)

class IntFilter(SeqFilter):
    def load(self, node):
        if node.nodeType != self.nodeType:
            return False
        if not node.value.isdigit(): # What about negative numbers?
            return False
        node.value = int(node.value)
        return True


# vim: sw=4 ts=4 expandtab ai
