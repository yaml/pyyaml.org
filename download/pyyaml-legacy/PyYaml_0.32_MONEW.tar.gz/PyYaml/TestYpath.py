import yaml
from test import assertEquals

try:    
    for test in yaml.loadFile("./TestingSuite/ypath.yml"):
        if not test.has_key('ignore'):
            expr = test['ypath']
            pth = yaml.ypath(expr,cntx=1)
            lst = [] 
            for x in pth.apply(test['data']):
                lst.append(str(x))
            exp = test['expected']
            if test.has_key('unordered'):
               lst.sort()
               exp.sort()
            assertEquals(lst,exp,expr + " => " + str(pth))

    print "Experimental YPATH OK"
except NotImplementedError: 
    print "Experimental YPATH requires Python 2.2"
