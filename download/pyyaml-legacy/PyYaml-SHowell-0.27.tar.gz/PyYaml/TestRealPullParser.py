def testSimplePull(self):
