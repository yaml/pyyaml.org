__version__ = "0.25"
from load import loadFile
from load import load
from dump import dump
from dump import dumpToFile
from dump import Dumper
from timestamp import timestamp

try:
    from ypath import ypath
except NameError:
    def ypath(expr,target='',cntx=''):
        raise NotImplementedError("ypath requires Python 2.2")
