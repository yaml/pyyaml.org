import new
import re

class DefaultResolver:
    def resolveType(self, data, typestring):
        match = re.match('!!(.*?)\.(.*)', typestring)
        if not match:
            raise "Invalid private type specifier"
        (modname, classname) = match.groups()
        return makeClass(modname, classname, data)

def makeClass(module, classname, dict):
    exec('import %s' % (module))
    klass = eval('%s.%s' % (module, classname))
    obj = new.instance(klass) 
    if hasMethod(obj, 'from_yaml'):
        return obj.from_yaml(dict)
    obj.__dict__ = dict
    return obj

def hasMethod(object, method_name):
    klass = object.__class__
    if not hasattr(klass, method_name):
        return 0
    method = getattr(klass, method_name)
    if not callable(method):
        return 0
    return 1

