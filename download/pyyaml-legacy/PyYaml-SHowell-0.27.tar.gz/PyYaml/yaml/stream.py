import re
import string

def indentLevel(line):
    n = 0
    while n < len(line) and line[n] == ' ':
        n = n + 1
    return n

class AbstractStream:
    def __init__(self):
        self.curLine = 0
        self.peeked = 0

    def peek(self):
        if self.peeked:
            return self.line
        self.line = self.getLine()
        self.curLine += 1
        self.peeked = 1
        if self.line:
            self.line = noLineFeed(self.line)
        return self.line

    def pop(self):
        data = self.peek()
        self.peeked = 0
        return data            

    def lastLineRead(self):
        # self.curLine works here, cause calling 
        # method expects 1-based indexing
        return self.curLine

class FileStream(AbstractStream):
    def __init__(self, filename):
        self.fp = open(filename)
        AbstractStream.__init__(self)

    def getLine(self):
        line = self.fp.readline()
        if line == '': line = None
        return line

class StringStream(AbstractStream):
    def __init__(self, text):
        self.lines = string.split(text, '\n')
        self.numLines = len(self.lines)
        AbstractStream.__init__(self)

    def getLine(self):
        if self.curLine < self.numLines:
            return self.lines[self.curLine]

class NestedText:
    def __init__(self, stream):
        self.stream = stream
        self.reset()

    def reset(self):
        self.indentLevel = 0
        self.oldIndents = [0]

    def lastLineRead(self):
        return self.stream.lastLineRead()

    def _peek(self):
        self.eatComments()
        return self.stream.peek()

    def peek(self):
        nextLine = self._peek()
        if nextLine is not None:
            if indentLevel(nextLine) >= self.indentLevel:
                return nextLine[self.indentLevel:]
            elif nextLine == '':
                return ''                

    def pop(self):
        line = self.peek()
        if line is None:
            self.indentLevel = self.oldIndents.pop()
            return
        self.stream.pop()
        return line

    def popNestedLines(self):
        nextLine = self.peek()
        if nextLine is None or nextLine == '' or nextLine[0] != ' ':
            return []
        self.nestToNextLine()
        lines = []
        while 1:
            line = self.pop()
            if line is None:
                break
            lines.append(line)
        return lines

    def eatComments(self):
        while 1:
            line = self.stream.peek() 
            if line is None or not re.match("\s*#", line):
                return
            self.stream.pop()

    def eatNewLines(self):
        while 1:
           line = self.stream.peek()
           if line is None or len(string.strip(line)):
               return
           self.stream.pop()

    def nestToNextLine(self):
        self.eatComments()
        line = self.stream.peek()
        indentation = indentLevel(line)
        if len(self.oldIndents) > 1 and indentation <= self.indentLevel:
            self.error("Inadequate indentation", line)
        self.setNewIndent(indentation)

    def nestBySpecificAmount(self, adjust):
        self.setNewIndent(self.indentLevel + adjust)
        
    def setNewIndent(self, indentLevel):
        self.oldIndents.append(self.indentLevel)
        self.indentLevel = indentLevel    

class NestedDocs(NestedText):
    def __init__(self, stream):
        NestedText.__init__(self,stream)
        self.eatNewLines()
        line = NestedText.peek(self)
        self.sep = '---'
        if self.startsWithSep(line):
            self.eatenDocSep = NestedText.pop(self)
        else:
            self.eatenDocSep = self.sep

    def startsWithSep(self,line):
        if line and self.sep == line[:3]: return 1
        return 0

    def popDocSep(self):
        line = self.eatenDocSep
        self.eatenDocSep = None
        self.reset()
        return line

    def pop(self):
        if self.eatenDocSep is not None:
            raise "error"
        line = self._peek()
        if line and self.startsWithSep(line):
            self.eatenDocSep = NestedText.pop(self)
            return None
        return NestedText.pop(self)

    def error(self, msg, line):
        raise Exception("%s:\n" "near line %d:\n" "%s\n" % 
            (msg, self.lastLineRead(), line))

def noLineFeed(s):
    while s[-1:] in ('\n', '\r'):
        s = s[:-1]
    return s
