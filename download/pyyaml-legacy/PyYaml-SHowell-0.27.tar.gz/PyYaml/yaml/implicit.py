import re
import string
from timestamp import timestamp, matchTime

def convertImplicit(val):
    if val == '~':
        return None
    if val == '+':
        return 1
    if val == '-':
        return 0
    if val[0] == "'" and val[-1] == "'":
        val = val[1:-1]
        return string.replace(val, "''", "\'")
    if val[0] == '"' and val[-1] == '"':
        if re.search(r"\u", val):
            val = "u" + val
        unescapedStr = eval (val)
        return unescapedStr
    if matchTime.match(val):
        return timestamp(val)
    if re.match("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", val):
        return val
    if re.match("^[-+]?[0-9][0-9,]*\.[0-9,]*$", val):
        return float(cleanseNumber(val))
    if re.match("^[-+]?[0-9][0-9,]*\.[0-9.]*[eE][-+][0-9]+$", val):
        return float(cleanseNumber(val))
    if re.match("^[-+]?([0][0-7,]*)$", val):
        return int(val, 8)
    if re.match("^[-+]?0x[0-9a-fA-F,]+$", val):
        return int(val, 16)
    if re.match("^[-+]?(0|[1-9][0-9,]*)$", val):
        return int(cleanseNumber(val))
    return val

def cleanseNumber(str):
    if str[0] == '+':
        str = str[1:]
    str = string.replace(str,',','')
    return str

