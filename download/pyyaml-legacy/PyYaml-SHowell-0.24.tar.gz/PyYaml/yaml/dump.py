import types
import string
from types import StringType, IntType, FloatType
from types import DictType, ListType, TupleType, InstanceType
import re

PRIVATE_NOTICE = """
  This module is considered to be private implementation
  details and is subject to change.  Please only use the
  objects and methods exported to the top level yaml package.
"""

try:
   from types import UnicodeType
   hasUnicode = 1
except:
   hasUnicode = 0
   UnicodeType = StringType

def accumulate(obj,occur):
    typ = type(obj)
    if obj is None or \
       typ is IntType or \
       typ is FloatType or \
       ((typ is StringType or typ is UnicodeType) \
       and len(obj) < 32): return
    obid = id(obj)
    if 0 == occur.get(obid,0):
        occur[obid] = 1
        if typ is ListType:
            for x in obj: 
                accumulate(x,occur)
        if typ is DictType:
            for (x,y) in obj.items():
                accumulate(x,occur)
                accumulate(y,occur)
    else:
        occur[obid] = occur[obid] + 1

class YamlAnchors:
     def __init__(self,data):
         occur = {}
         accumulate(data,occur)
         anchorVisits = {}
         for (obid, occur) in occur.items():
             if occur > 1:
                 anchorVisits[obid] = 0 
         self._anchorVisits = anchorVisits
         self._currentAliasIndex     = 0
     def shouldAnchor(self,obj):
         ret = self._anchorVisits.get(id(obj),None)
         if 0 == ret:
             self._currentAliasIndex = self._currentAliasIndex + 1
             ret = self._currentAliasIndex
             self._anchorVisits[id(obj)] = ret
             return ret
         return 0
     def isAlias(self,obj):
         return self._anchorVisits.get(id(obj),0)

def sort_keys(keys,fn):
    tmp = []
    for key in keys:
        val = fn(key)
        if val is None: val = '~'
        tmp.append((val,key))
    tmp.sort()
    return [ y for (x,y) in tmp ]

def alpha_sort(): pass

def dump(data, indent="    ",sort=alpha_sort):
    typ = type(sort)
    if DictType == typ:
        sort = sort.get
    elif ListType == typ or TupleType == typ:
        tmp = {}; idx = 0
        for x in sort:
            tmp[x] = idx
            idx += 1
        sort = tmp.get
    anchors = YamlAnchors(data)
    result = []
    dmp = YamlDump("\n", indent,anchors,result,sort)
    result.append("---")
    dmp.dumpData(data)
    result.append("\n")
    return string.join(dmp.result,"")

class YamlDump:
    def __init__(self, indent, reIndent, anchors, result, keysrt):
        self.indent   = indent
        self.reIndent = reIndent
        self.anchors  = anchors
        self.result   = result
        self.keysrt   = keysrt

    def output(self, data):
        self.result.append(data)

    def indentDump(self, data):
        newIndent = self.indent + self.reIndent
        dmpr = YamlDump(newIndent, self.reIndent,self.anchors,
                        self.result, self.keysrt)
        dmpr.dumpData(data)

    def dumpData(self, data):
        anchor = self.anchors.shouldAnchor(data)
        if anchor: 
            self.output(" &%d" % anchor )
        else:
            anchor = self.anchors.isAlias(data)
            if anchor:
                self.output(" *%d" % anchor )
                return
        if (data is None):
            self.output(' ~')
        elif type(data) is InstanceType:
            if hasMethod(data, '__yaml__'):
                dmp = data.__yaml__()
            else:
                dmp = data.__dict__
            typ = type(dmp)
            if typ is DictType:
                self.dumpDict(dmp)
            elif typ is StringType:
                self.output(" " + dmp)
            else:
                raise "unexpected __yaml__ type: " + repr(typ)
        elif type(data) is DictType:
            self.dumpDict(data)
        elif type(data) in [ListType, TupleType]:
            self.dumpList(data)
        else:
            self.dumpScalar(data)

    def dumpDict(self, data):
        keys = data.keys()
        if len(keys) == 0:
            self.output(" {}")
            return
        if self.keysrt:
            if alpha_sort == self.keysrt:
                keys.sort()
            else: 
                keys = sort_keys(keys,self.keysrt)
        for key in keys:
            self.output(self.indent)
            self.dumpKey(key)
            self.output(":")
            self.indentDump(data[key])

    def dumpKey(self, key):
        if type(key) is TupleType:
            self.output("?")
            self.indentDump(key) 
            self.output("\n")
        else:
            self.output(quote(key))

    def dumpList(self, data):
        if len(data) == 0:
            self.output(" []")
            return
        for item in data:
            self.output(self.indent)
            self.output("-")
            self.indentDump(item)

    def dumpScalar(self, data):
        data = cleanUnicode(data)
        if type(data) != str:
            self.output(" ")
            self.output(str(data))
        elif isMulti(data):
            self.dumpMultiLineScalar(data.splitlines())
        else:
            self.output(" ")
            self.output(quote(data))
    
    def dumpMultiLineScalar(self, lines):
        self.output(" |")
        for line in lines:
            self.output(self.indent)
            self.output(line)

def hasMethod(object, method_name):
    klass = object.__class__
    if not hasattr(klass, method_name):
        return 0
    method = getattr(klass, method_name)
    if not callable(method):
        return 0
    return 1

def quote(data):
    single = "'"
    double = '"'
    quote = ''
    if len(data) == 0:
        return "''"
    if hasSpecialChar(data) or data[0] == single:
        data = `data`[1:-1]
        data = string.replace(data, r"\x08", r"\b")
        quote = double 
    if needsSingleQuote(data):
        quote = single
    return "%s%s%s" % (quote, data, quote)

def needsSingleQuote(data):
    if re.match("^\d*$", data):
        return 1
    return (re.search(r'[-:]', data) or re.search(r'(\d\.){2}', data))

def hasSpecialChar(data):
    # need test to drive out '#' from this
    return re.search(r'[\t\b\r\f#]', data)

def cleanUnicode(data):
    if hasUnicode and type(data) == unicode:
        return '"' + data.__repr__()[2:-1] + '"'
    return data

def isMulti(data):
    if hasSpecialChar(data):
        return 0
    return re.search("\n", data)
       

