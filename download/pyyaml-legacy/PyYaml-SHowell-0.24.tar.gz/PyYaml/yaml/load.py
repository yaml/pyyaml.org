import string, re, time
from timestamp import timestamp, matchTime
from string import strip

PRIVATE_NOTICE = """
  This module is considered to be private implementation
  details and is subject to change.  Please only use the
  objects and methods exported to the top level yaml package.
"""

try:
    iter(list())
    StopIteration = StopIteration    
    class loadIterator:
        def __init__(self,parser):
            self._parser = parser
        def __iter__(self):
            return self
        def next(self):
            return self._parser.getNextDocument() 
        __next__ = next

except:
   class StopIteration: pass
   def iter(x): return x
   class loadIterator:
       def __init__(self,parser):
           self._docs = []
           try:
               while 1:
                  self._docs.append(parser.getNextDocument())
           except StopIteration: pass
           self._idx = 0
       def __len__(self): return len(self._docs)
       def __getitem__(self,idx): return self._docs[idx]
       def next(self):
           if self._idx < len(self._docs):
               ret = self._docs[self._idx] 
               self._idx = self._idx + 1
               return ret
           raise StopIteration
       __next__ = next

def loadFile(file, typeResolver=None):
    f = open(file)
    stream = f.read()
    f.close()
    return load(stream,typeResolver)
   
def load(stream, typeResolver=None):
    return iter(loadIterator(Parser(stream, typeResolver)))

def cleanseNumber(str):
    if str[0] == '+':
        str = str[1:]
    str = string.replace(str,',','')
    return str

def native(val):
    # XXX - Clark and I decided to move this to its own file.
    if val == '~':
        return None
    if val == '+':
        return 1
    if val == '-':
        return 0
    if val[0] == "'" and val[-1] == "'":
        val = val[1:-1]
        return string.replace(val, "''", "\'")
    if val[0] == '"' and val[-1] == '"':
        if re.search(r"\u", val):
            val = "u" + val
        unescapedStr = eval (val)
        return unescapedStr
    if matchTime.match(val):
        return timestamp(val)
    if re.match("^[0-9]{4}-[0-9]{2}-[0-9]{2}$", val):
        return val
    if re.match("^[-+]?[0-9][0-9,]*\.[0-9,]*$", val):
        return float(cleanseNumber(val))
    if re.match("^[-+]?[0-9][0-9,]*\.[0-9.]*[eE][-+][0-9]+$", val):
        return float(cleanseNumber(val))
    if re.match("^[-+]?([0][0-7,]*)$", val):
        return int(val, 8)
    if re.match("^[-+]?0x[0-9a-fA-F,]+$", val):
        return int(val, 16)
    if re.match("^[-+]?(0|[1-9][0-9,]*)$", val):
        return int(cleanseNumber(val))
    return val

def tryProductions(productions, value):
    for production in productions:
        results = production(value)
        if results:
            (ok, result) = results
            if ok:
                return (1, result)

class Parser:
    def __init__(self, stream, typeResolver=None):
        self.nestedDocs = NestedDocs(stream)
        self.typeResolver = typeResolver
        self.aliases = {}

    def error(self, msg):
        raise Exception("%s:\n" "near line %d:\n" "%s\n" % 
            (msg, self.nestedDocs.lastLineRead(), self.line))

    def nestPop(self):
        line = self.nestedDocs.pop()
        if line is not None:
            self.line = line
            return 1

    def value(self, indicator):
        return getToken(indicator+"\s*(.*)", self.line)

    def getNextDocument(self):
        line = self.nestedDocs.popDocSep()
        indicator = getIndicator(line)
        if indicator:
            productions = [
                self.parseSpecial,
                self.parseNative
            ]
            (ok, scalar) = tryProductions(productions, indicator)
            return scalar
        if line:
            self.nestedDocs.nestToNextLine()
            return self.parseLines()
        raise StopIteration

    def parseLines(self):
        peekLine = self.nestedDocs.peek()
        if peekLine:
            if re.match("\s*-", peekLine):
                return self.parse_collection([], self.parse_seq_line)
            else:
                return self.parse_collection({}, self.parse_map_line)
        raise StopIteration

    def parse_collection(self, items, lineParser):
        while self.nestPop():
            if self.line:
                lineParser(items)
        return items    

    def parse_seq_line(self, items):
        value = self.value("-")
        if value is not None:
            items.append(self.parse_seq_value(value))
        else:
            self.error("missing '-' for seq")

    def parse_map_line(self, items):
        if (self.line == '?'):
            self.parse_map_line_nested(items)
        else:
            self.parse_map_line_simple(items, self.line)

    def parse_map_line_nested(self, items):
        self.nestedDocs.nestToNextLine()
        key = self.parseLines()
        if self.nestPop():
            value = self.value(':')
            if value is not None:
                items[tuple(key)] = self.parse_value(value)
                return
        self.error("key has no value for nested map")

    def parse_map_line_simple(self, items, line):
        map_item = key_value(line)
        if map_item:
            (key, value) = map_item
            items[key] = self.parse_value(value)
        else:
            self.error("bad key for map")

    def is_map(self, value):
        # XXX - need real tokenizer
        if len(value) == 0:
            return 0
        if value[0] == "'":
            return 0
        if re.search(':(\s|$)', value):       
            return 1

    def parse_seq_value(self, value):
        if self.is_map(value):
            return self.parse_compressed_map(value)
        else:
            return self.parse_value(value)

    def parse_compressed_map(self, value):
        items = {}
        line = self.line
        token = getToken("(\s*-\s*)", line)
        self.nestedDocs.nestBySpecificAmount(len(token))
        self.parse_map_line_simple(items, value)
        return self.parse_collection(items, self.parse_map_line)

    def parse_value(self, value):
        (alias, value) = self.lookup(value)
        if alias:
            return value
        (alias, value) = self.alias(value)            
        value = self.parse_unaliased_value(value)
        if alias:
            self.aliases[alias] = value
        return value          

    def parse_unaliased_value(self, value):
        match = re.match(r"(!\S*)(.*)", value)
        if match:
            (url, value) = match.groups()
            return self.typeResolver.resolveType(
                self.parse_untyped_value(value),
                url)
        return self.parse_untyped_value(value)

    def parseInlineArray(self, value):        
        if re.match("\s*\[", value):
            return self.parseInline([], value, ']', 
                self.parseInlineArrayItem)

    def parseInlineHash(self, value):        
        if re.match("\s*{", value):
            return self.parseInline({}, value, '}', 
                self.parseInlineHashItem)

    def parseInlineArrayItem(self, result, token):
        return result.append(native(token))

    def parseInlineHashItem(self, result, token):
        (key, value) = key_value(token)
        result[key] = value

    def parseInline(self, result, value, end_marker, itemMethod):
        tokenizer = InlineTokenizer(value)
        tokenizer.next()
        while 1:
            token = tokenizer.next()
            if token == end_marker:
                break
            itemMethod(result, token)
        return (1, result)

    def parseSpecial(self, value):
        productions = [
            self.parseMultiLineScalar,
            self.parseInlineHash,
            self.parseInlineArray,
        ]
        return tryProductions(productions, value)

    def parse_untyped_value(self, value):
        parse = self.parseSpecial(value)
        if parse:
            (ok, data) = parse
            return data
        token = getToken("(\S.*)", value)
        if token:
            lines = [token] + \
                pruneTrailingEmpties(self.nestedDocs.popNestedLines())
            return native(joinLines(lines))
        else:
            self.nestedDocs.nestToNextLine()
            return self.parseLines()

    def parseNative(self, value):
        return (1, native(value))

    def parseMultiLineScalar(self, value):
        if value == '>':
            return (1, self.parseFolded())
        elif value == '|':
            return (1, self.parseLiteral())

    def parseFolded(self):
        data = self.parseBlock()
        i = 0
        resultString = ''
        while i < len(data)-1:
            resultString = resultString + data[i]
            resultString = resultString + foldChar(data[i], data[i+1])
            i = i + 1
        return resultString + data[-1] + "\n"        

    def parseLiteral(self):
        return string.join(self.parseBlock(),"\n") + "\n"

    def parseBlock(self):
        self.nestedDocs.nestToNextLine()
        data = []
        while self.nestPop():
            data.append(self.line)
        return pruneTrailingEmpties(data)

    def alias(self, value):
        match = re.match("&(\S*)\s*(.*)", value)
        if match:
            return match.groups()
        return (None, value)

    def lookup(self, value):
        match = re.match("\*(\S*)", value)
        if match:
            alias = match.groups()[0]
            if self.aliases.has_key(alias):
                return (alias, self.aliases[alias])
            else:
                self.error("Unknown alias")
        return (None, value)

def getToken(regex, value):
    match = re.search(regex, value)
    if match:
        return match.groups()[0]

def key_value(str):
    # XXX This allows mis-balanced " vs. ' stuff
    match = re.match("[\"'](.+)[\"']\s*:\s*(.*)", str)
    if match:
        (key, value) = match.groups()
        return (key, value)

    match = re.match("(.+?)\s*:\s*(.*)", str)
    if match:
        (key, value) = match.groups()
        if len(value) and value[0] == '#':
            value = ''
        return (key, value)

def pruneTrailingEmpties(data):
    while len(data) > 0 and data[-1] == '':
        data = data[:-1]
    return data

def foldChar(line1, line2):
    if re.match("^\S", line1) and re.match("^\S", line2):
        return " "
    return "\n"

def getIndicator(line):
    if line:
        header = r"(#YAML:\d+\.\d+\s*){0,1}"
        match = re.match("--- "+header+"(\S*.*)", line)
        if match:
            return match.groups()[-1]

def joinLines(lines):
    result = ''
    for line in lines[:-1]:
        if line[-1] == '\\':
            result = result + line[:-1]
        else:
            result = result + line + " "
    return result + lines[-1]


def indentLevel(line):
    n = 0
    while n < len(line) and line[n] == ' ':
        n = n + 1
    return n

class Stream:
    def __init__(self, text):
        self.lines = string.split(text, '\n')
        self.curLine = 0
        self.numLines = len(self.lines)

    def peek(self):
        if self.curLine < self.numLines:
            return self.lines[self.curLine]

    def pop(self):
        if self.curLine < self.numLines:
            line = self.lines[self.curLine]
            self.curLine += 1
            return line

    def lastLineRead(self):
        # self.curLine works here, cause calling 
        # method expects 1-based indexing
        return self.curLine

class NestedText:
    def __init__(self, text):
        self.stream = Stream(text)
        self.indentLevel = 0
        self.oldIndents = [0]

    def lastLineRead(self):
        return self.stream.lastLineRead()

    def _peek(self):
        self.eatComments()
        return self.stream.peek()

    def peek(self):
        nextLine = self._peek()
        if nextLine is not None:
            if indentLevel(nextLine) >= self.indentLevel:
                return nextLine[self.indentLevel:]
            elif nextLine == '':
                return ''                

    def pop(self):
        line = self.peek()
        if line is None:
            self.indentLevel = self.oldIndents.pop()
            return
        self.stream.pop()
        return line

    def popNestedLines(self):
        nextLine = self.peek()
        if nextLine is None or indentLevel(self.peek()) <= self.indentLevel:
            return []
        self.nestToNextLine()
        lines = []
        while 1:
            line = self.pop()
            if line is None:
                break
            lines.append(line)
        return lines

    def eatComments(self):
        while 1:
            line = self.stream.peek() 
            if line is None or not re.match("\s*#", line):
                return
            self.stream.pop()

    def eatNewLines(self):
        while 1:
           line = self.stream.peek()
           if line is None or len(string.strip(line)):
               return
           self.stream.pop()

    def nestToNextLine(self):
        self.eatComments()
        self.setNewIndent(indentLevel(self.stream.peek()))

    def nestBySpecificAmount(self, adjust):
        self.setNewIndent(self.indentLevel + adjust)
        
    def setNewIndent(self, indentLevel):
        self.oldIndents.append(self.indentLevel)
        self.indentLevel = indentLevel    

class NestedDocs(NestedText):
    def __init__(self, stream):
        NestedText.__init__(self,stream)
        self.eatNewLines()
        line = NestedText.peek(self)
        self.sep = '---'
        if self.startsWithSep(line):
            self.eatenDocSep = NestedText.pop(self)
        else:
            self.eatenDocSep = self.sep

    def startsWithSep(self,line):
        if line and self.sep == line[:3]: return 1
        return 0

    def popDocSep(self):
        line = self.eatenDocSep
        self.eatenDocSep = None
        return line

    def pop(self):
        if self.eatenDocSep is not None:
            raise "error"
        line = self._peek()
        if line and self.startsWithSep(line):
            self.eatenDocSep = NestedText.pop(self)
            return None
        return NestedText.pop(self)

class InlineTokenizer:
    def __init__(self, data):
        self.data = data

    def punctuation(self):
        puncts = [ '[', ']', '{', '}' ]
        for punct in puncts:
            if self.data[0] == punct:
                self.data = self.data[1:]
                return punct

    def up_to_comma(self):
        match = re.match('(.*?)\s*,(.*)', self.data)
        if match: 
            self.data = match.groups()[1]
            return match.groups()[0]

    def up_to_end_brace(self):
        match = re.match('(.*?)(\s*[\]}].*)', self.data)
        if match: 
            self.data = match.groups()[1]
            return match.groups()[0]

    def next(self):
        self.data = string.strip(self.data)
        productions = [
            self.punctuation,
            self.up_to_comma,
            self.up_to_end_brace
        ]
        for production in productions:
            token = production()
            if token:
                return token
