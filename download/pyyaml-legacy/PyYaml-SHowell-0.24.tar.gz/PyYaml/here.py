import re
from string import split, join

def here(s):
    lines = split(s,'\n')
    lastLine = lines.pop()
    if re.match(r"\S", lastLine):
        raise "bad last line"
    indent = len(lastLine)
    ret = []
    for line in lines[1:]:
        ret.append(line[indent:] + '\n')
    return join(ret,'')
