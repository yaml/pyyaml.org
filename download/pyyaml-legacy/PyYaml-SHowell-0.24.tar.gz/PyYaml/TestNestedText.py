import YamlTest
from yaml.load import *
from here import *
from test import assertEquals

class Test(YamlTest.YamlTest):
    def tryPop(self, expected):
        assertEquals(self.nt.pop(), expected)
        
    def tryPopNestedLines(self, expected):
        assertEquals(self.nt.popNestedLines(), expected)
        
    def tryPeek(self, expected):
        assertEquals(self.nt.peek(), expected)

    def test1(self):
        self.nt = NestedText(here(
            """
            1a
             2a
             2b
                 3a
             2c
            1b
            """))
        self.tryPop('1a')
        self.nt.nestToNextLine()
        self.tryPop('2a')
        self.tryPop('2b')
        self.nt.nestToNextLine()
        self.tryPop('3a')
        self.tryPop(None)
        self.tryPop('2c')
        self.tryPop(None)
        self.tryPeek('1b')
        self.tryPop('1b')
        self.tryPop('')
        self.tryPop(None)
        
    def test2(self):
        self.nt = NestedText(here("""
            apple
                banana
                   foo
            """))
        self.tryPop('apple')
        self.nt.nestToNextLine()
        self.tryPop('banana')
        self.nt.nestBySpecificAmount(2)
        self.tryPop(' foo')

    def test3(self):
        self.nt = NestedDocs(here("""
            seattle
            --- foo
            bluffton
            """))
        assertEquals(self.nt.popDocSep(), '---')
        self.tryPop('seattle')
        self.tryPop(None)
        assertEquals(self.nt.popDocSep(), '--- foo')
        self.tryPop('bluffton')
        self.tryPop('')
        self.tryPop(None)

    def testEatComments(self):
        data = here("""
            # ignore
              # these
            silly
            """)
        self.nt = NestedText(data)
        self.nt.eatComments()
        self.tryPop('silly')

    def testNestedDocsEatComments(self):
        data = here("""
            # foo
              # bar
            ---
            shabazz
            """)
        self.nt = NestedDocs(data)
        self.nt.popDocSep()
        self.tryPop('shabazz')
        assertEquals(self.nt.lastLineRead(), 4)

    def testNestedTextEatNewline(self):
        data = here("""
            
            ---
            shabazz
            """)
        self.nt = NestedDocs(data)
        self.nt.popDocSep()
        self.tryPop('shabazz')

    def testDocSep(self):
        data = here("""
            --- city
            seattle
            --- town
            bluffton
            """)
        self.nt = NestedDocs(data)
        assertEquals(self.nt.popDocSep(), '--- city')
        self.tryPop('seattle')
        self.tryPop(None)
        assertEquals(self.nt.popDocSep(), '--- town')
        self.tryPop('bluffton')
        self.tryPop('')
        self.tryPop(None)

        data = here("""
            # comments at top
            # should be ignored
            """) + data
        self.nt = NestedDocs(data)
        assertEquals(self.nt.popDocSep(), '--- city')
        self.tryPop('seattle')

    def testNestedComments(self):
        self.nt = NestedText(here("""
            apple
              # ignore this comment
                banana
                   foo
            """))
        self.tryPop('apple')
        self.nt.nestToNextLine()
        self.tryPop('banana')
        self.nt.nestBySpecificAmount(2)
        self.tryPop(' foo')

    def testStream(self):
        stream = Stream(here("""
            python
            perl
            java
            """))
        assertEquals(stream.pop(), "python")
        assertEquals(stream.peek(), "perl")
        assertEquals(stream.pop(), "perl")
        assertEquals(stream.pop(), "java")
        assertEquals(stream.pop(), "")
        
    def test1(self):
        self.nt = NestedText(here(
            """
            1a
             2a
             2b
                 3a
             2c
            1b
            """))
        self.tryPop('1a')
        self.nt.nestToNextLine()
        self.tryPop('2a')
        self.tryPop('2b')
        self.nt.nestToNextLine()
        self.tryPop('3a')
        self.tryPop(None)
        self.tryPop('2c')
        self.tryPop(None)
        self.tryPeek('1b')
        self.tryPop('1b')
        self.tryPop('')
        self.tryPop(None)
        
    def testEmptyLines(self):
        self.nt = NestedDocs(here("""
            ---
             apple

                banana
            """))
        self.nt.popDocSep()
        self.nt.nestToNextLine()
        self.tryPop('apple')
        self.nt.nestToNextLine()
        self.tryPop('')
        self.nt.nestToNextLine()
        self.tryPop('banana')

    def testFoldedCase(self):
        self.nt = NestedText(here(
            """
            ---
             Aaa
             Bbb

               11
               22

             Ccc
            """))
        self.nt.pop()
        self.nt.nestToNextLine()
        self.tryPop('Aaa')
        self.tryPop('Bbb')
        self.tryPop('')

    def testRedHerringDocSep(self):
        self.nt = NestedDocs(here(
            """
            ---
            foo:
                ---
            """))
        self.nt.popDocSep()
        self.tryPop('foo:')
        self.nt.nestToNextLine()
        self.tryPop('---')

    def testGetToNextIndent(self):
        self.nt = NestedText(here(
            """
            ---
            line1: this is
               continued
            line2
            """))
        self.nt.pop()
        self.nt.nestToNextLine()
        self.tryPop('line1: this is')
        self.tryPopNestedLines(['continued'])
        self.tryPop('line2')
            
    def testGetToNextIndent(self):
        self.nt = NestedText(here(
            """
            ---
            line1: this is
               continued
               with multiple lines
            line2
            """))
        self.nt.pop()
        self.nt.nestToNextLine()
        self.tryPop('line1: this is')
        self.tryPopNestedLines(['continued', 'with multiple lines'])
        self.tryPop('line2')
            
    def testPopNestedLinesWithNoneNested(self):
        self.nt = NestedText(here(
            """
            ---
            - apple
            - banana
            - carrot
            """))
        self.nt.pop()
        self.nt.nestToNextLine()
        self.tryPop('- apple')
        self.tryPopNestedLines([])
        self.tryPop('- banana')

    def testLineNumbers(self):
        data = here(
            """
            one
            two
            #
            three
            """)
        stream = Stream(data)
        stream.pop()
        assertEquals(stream.lastLineRead(), 1)
        stream.pop()
        assertEquals(stream.lastLineRead(), 2)
        nt = NestedText(data)
        nt.pop()
        assertEquals(nt.lastLineRead(), 1)
        nt.pop()
        assertEquals(nt.lastLineRead(), 2)
        nt.pop()  # eats a comment too
        assertEquals(nt.lastLineRead(), 4)


        

if __name__ == '__main__':
    import unittest
    unittest.main()
