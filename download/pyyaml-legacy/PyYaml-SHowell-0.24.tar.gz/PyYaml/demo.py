import yaml

####### RUNNING YAML AGAINST THE README

readme = yaml.loadFile("README")
print "README"
for item in readme.next():
    print item
print "\n\nCONTRIBUTORS"
for person in readme.next()['contributors']:
    print "===%s===" % person['who']
    print person['why?']
    print
print "\n\n"

######## USING YAML INSIDE YOUR PROGRAM

testData = \
"""
program: PyYaml
author: Steve Howell
---
shopping list:
 - apple
 - banana
todo:
 - eat more fruit:
     - especially bananas!
     - good for you
 - write a better demo
"""

print "YAML INSIDE YOUR PROGRAM"
for x in yaml.load(testData):
   print repr(x)
print "\n\n"


######### YPATH STUFF

try:
    print "YPATH EXPERIMENTATION"
    data = yaml.load(testData)
    print yaml.ypath("/author",data.next()).next()
    print yaml.dump(yaml.ypath("/todo/0",data.next()).next())
except NotImplementedError:
    print "Experimental YPATH requires Python 2.2"
