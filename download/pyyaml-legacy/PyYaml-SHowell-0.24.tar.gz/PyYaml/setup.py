from distutils.core import setup
setup (name = "yaml",
       version = "0.2",
       packages = ["yaml"])
