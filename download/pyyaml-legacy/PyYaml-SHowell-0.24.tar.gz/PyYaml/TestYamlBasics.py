import YamlTest
from here import *

class Test(YamlTest.YamlTest):
    def setUp(self):
        # print '>>>>>>>>>>>>>>>'
        pass

    def XXXtest9(self):
        # XXX - not sure how this gets handled now
        self.verify(
            """
            - foo: 1
                bar: 2
            """,
            [ {'foo': 1, '  bar': 2}])

    def testOutlineSnippet(self):
        self.verify(
            """
            - YAML ToDo:
                - y2outline
                - support generic transfers
                - work on YAML.py:
                    - work on Store
            """,
            [ {'YAML ToDo': [   
                'y2outline',
                'support generic transfers',
                { 'work on YAML.py': ['work on Store'] }
                ]
              }
            ])

    def testQuotedString(self):
        self.verify(
            """
            ---
            foo: 'key: value'
            """,
            {'foo': "key: value"}
            )

    def testFloatRedHerring(self):
        self.verify(
            """
            ---
            - 'Version: 0.18.0'
            """,
            [ 'Version: 0.18.0' ]
            )

    def testDashInQuotes(self):
        self.verify(
            """
            ---
            title: 'Perspective Broker - twisted.spread'
            """,
            {'title': 'Perspective Broker - twisted.spread'}
            )

    def testQuestionMarks(self):
        self.verify(
            """
            ---
            hello: you there?
            foo:
                - ok?
                - sure?
            bar:
                - for here or to go?
                - more sugar?
            """,
            {   
                'hello': 'you there?',
                'foo': ['ok?', 'sure?'],
                'bar': ['for here or to go?', 'more sugar?']
            }
            )

    def testDoubleQuoteEscapedKeys(self):
        self.verify(
            """
            ---
            "I'm escaped!": simple
            """,
            { "I'm escaped!": 'simple' }
            )

    def testColonsInsideEscapedKeys(self):
        self.verify(
            """
            ---
            'aaa: bbbb': simple
            """,
            { 'aaa: bbbb': 'simple' }
            )

    def testControlChars(self):
        self.verify(
            r"""
            control: "\b1998\t1999\t2000\n"
            """,
            { 'control': "\b1998\t1999\t2000\n" }
        )

    def testUnicode(self):
        if YamlTest.hasUnicode:
            self.verify(
                r'''
                unicode: "Sosa did fine.\u263A"
                ''',
                { 'unicode': u"Sosa did fine.\u263A"}
            )

    def testMultiLineScalar(self):
        self.verify(
            """
            plain: This unquoted
                   scalar spans
                   many lines.
            """,
            { 'plain': 'This unquoted scalar spans many lines.' }
        )

    def testDomainType(self):
        class MyYamlConfig:
            def resolveType(self, data, url):
                if url == '!name':
                    return 'Foo ' + data
                elif url == '!coords':
                    return { 'x': data[0], 'y': data[1]}
                else:
                    raise 'url not passed in correctly'
        data = YamlTest.loadHere("""
            name: !name Barson
            coords: !coords
              - 10
              - 20
            """, 
            MyYamlConfig())
        self.assertEquals(data[0], 
            {'name': 'Foo Barson',
            'coords': { 'x': 10, 'y': 20 } }
        )

if __name__ == '__main__':
    import unittest
    unittest.main()
