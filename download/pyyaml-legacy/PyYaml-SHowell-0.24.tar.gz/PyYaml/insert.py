from PyYaml import yaml
from test import assertEquals
from ypath import Ypath
import re

def Insert(data, command):
    if command.has_key('ypath'):
        Ypath(data, command['ypath']).append(command['value'])
        return data
    return data + [command['value']]

def TestInsert(data, command, expected):
    assertEquals(Insert(data, command), expected)    

doc = yaml.loadFile("insert.yml")[0]
for test in doc['tests']:
    if not test.has_key('ignore'):
        TestInsert(test['data'], test['command'], test['expected'])


