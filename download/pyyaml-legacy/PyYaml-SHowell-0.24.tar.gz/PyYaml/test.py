def assertEquals(first, second, msg=''):
    if first != second:
        raise AssertionError, \
              (msg + "\n%s !=\n%s" % (`first`, `second`))

