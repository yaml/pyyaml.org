import unittest, sys, string
import yaml
from here import *
import re
import glob
from test import assertEquals

try:
   unicode('')
   hasUnicode = 1
except:
   hasUnicode = 0


def loadHere(stream, typeResolver=None):
    return list(yaml.load(here(stream), typeResolver))

class YamlTest(unittest.TestCase):

    def runTest(self):
        # reinvent the wheel, instead of trying to 
        # understand unittest's braindead interface
        for name in dir(self.__class__):
            if re.match('test', name):
                exec('self.%s()' % name)

    def verify(self, stream, results):
        self.verifyMany(stream, [results])

    def verifyMany(self, stream, expected):
        results = loadHere(stream)
        assertEquals(results, expected)

class TestFromSpec(YamlTest):
    def assertRoundTrip(self, data):
        # XXX - A5 won't round trip when enclosed by 
        # an array...need to investigate
        for item in data:
            # print dump(item)
            assertEquals(item, 
                yaml.load(yaml.dump(item)).next(), 'roundtrip')

    def testFromYaml(self):
        testFiles = glob.glob('TestingSuite/*.yml')
        for file in testFiles:
            # print "\n\n\n\n", file
            try:
                docs = yaml.loadFile(file)
            except IOError:
                raise "See TESTING for how to set up TestingSuite"
            for doc in docs:
                if doc.has_key('python'):
                    data = eval(doc['python'])
                    # print data
                    assertEquals(list(yaml.load(doc['yaml'])), data)
                    if not doc.has_key('NO_ROUND_TRIP'):
                        self.assertRoundTrip(data)
                if doc.has_key('error') and doc['error'].has_key('python'):
                    errorTest(doc['yaml'], doc['error']['python'])

def errorTest(badYaml, expectedError):
    raised = 1
    try:
        ignore = list(yaml.load(badYaml))
        raised = 0
    except Exception, e:
        assertEquals(str(e), expectedError)
    if not raised:
        raise "Never got expected error for:\n%s" % badYaml
                        

if __name__ == '__main__':
    import TestYamlBasics
    import TestNestedText
    import TestInlineTokenizer
    ts = unittest.TestSuite()
    ts.addTest(TestYamlBasics.Test())
    ts.addTest(TestNestedText.Test())
    ts.addTest(TestInlineTokenizer.Test())
    ts.addTest(TestFromSpec())
    unittest.TextTestRunner().run(ts)
    # unittest.main()
