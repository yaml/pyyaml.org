import yaml

def writeFile(fn, data):
    f = open(fn, 'w')
    f.write(data)

writeFile('toplevel.yml', """
    - doc1: !!include doc1.yml
    - doc2: !!include doc2.yml
    """)

writeFile('doc1.yml', "foo: bar")
writeFile('doc2.yml', "more: stuff")

class Includer:
    def resolveType(self, value, url):
        return yaml.loadFile(value).next()

print yaml.loadFile('toplevel.yml', Includer()).next()
