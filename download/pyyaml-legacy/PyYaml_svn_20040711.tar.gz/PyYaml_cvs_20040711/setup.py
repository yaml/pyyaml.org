from distutils.core import setup
setup (name = "yaml",
       description = "A Pure Python Yaml Parser Dumper",
       version = "0.35",
       packages = ["yaml"],
       author = "Steve Howell et al"
       author_email = "info@pyyaml.dnsalias.org",
       url = "http://pyyaml.dnsalias.org/"
)
