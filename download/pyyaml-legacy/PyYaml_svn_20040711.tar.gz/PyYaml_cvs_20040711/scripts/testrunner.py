#!/usr/bin/env python

import os
import os.path
import sys
import types
import unittest


def loadModule(name):
    m = __import__(name)
    for n in name.split('.')[1:]:
        m = getattr(m, n)
    return m


def testModule(name):
    m = loadModule(name)
    tests = unittest.TestLoader().loadTestsFromModule(m)
    if tests:
        print 'Running %s tests' % name
        unittest.TextTestRunner().run(tests)
        

def testPackage(name):
    m = loadModule(name)
    pkgDir = os.path.dirname(m.__file__)
    for fname in os.listdir(pkgDir):
        if not os.path.isfile(os.path.join(pkgDir,fname)):
            continue
        n, e = os.path.splitext(fname)
        if n.startswith('test') and e == '.py':
            testModule('.'.join([name,n]))


def testAnything(name):
    m = loadModule(name)
    if isinstance(m, types.ModuleType):
        if os.path.basename(m.__file__).startswith('__init__.'):
            testPackage(name)
        else:
            testModule(name)


if __name__ == '__main__':
    sys.path[:0] = ['.']
    testAnything(sys.argv[1])
