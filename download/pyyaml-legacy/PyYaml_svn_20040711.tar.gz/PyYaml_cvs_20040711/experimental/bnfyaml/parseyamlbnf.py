"""Re-written version of simpleexample for 2.0"""
from simpleparse.common import numbers, strings, comments
from simpleparse.parser import Parser
import pprint

declaration = open('yamltest.bnf','r').read()
testData = open('datatest.yaml','r').read()
parser = Parser( declaration, "c_printable" )
if __name__ =="__main__":
	pprint.pprint( parser.parse( testData))
