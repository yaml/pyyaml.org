import yaml
import string
import pprint

testData = \
"""
program: PyYaml
nestedmapping: {hr: 65, avg: 0.278}
author: Steve Howell
---
shopping list:
 - apple
 - banana
todo:
 - eat more fruit:
     - especially bananas!
     - good for you
 - write a better demo
"""

for x in yaml.load(testData):
   pprint.pprint(x)

