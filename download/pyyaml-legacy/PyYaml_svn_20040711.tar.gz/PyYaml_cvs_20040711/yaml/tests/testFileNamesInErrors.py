#!/usr/bin/env python
import YamlTest
import yaml, re
from test import assertError

class Test(YamlTest.YamlTest):
    def testParseErrors(self):
        try:
            out = yaml.loadFile('TestFileNamesInErrors.py').next()
            assertError('Parsed an invalid file')
        except Exception, e:
            self.failUnless(re.search('TestFileNamesInErrors\.py', str(e)))
if __name__ == '__main__':
    import unittest
    unittest.main()