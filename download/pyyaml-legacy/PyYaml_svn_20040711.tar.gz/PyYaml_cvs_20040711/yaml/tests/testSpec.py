import YamlTest
import yaml
import re
import glob
from test import assertEquals, assertError
from here import flushLeft


def loadFlushLeft(stream, typeResolver=None):
    return list(yaml.load(flushLeft(stream), typeResolver))

class YamlLoader:
    # XXX python 2.1 has weak lambda support
    def __init__(self, doc):
        self.doc = doc
    def __call__(self):
        return list(yaml.load(self.doc['yaml']))

class Test(YamlTest.YamlTest):
    def testFromYaml(self):
        testFiles = glob.glob('./yaml/tests/TestingSuite/*.yml')
        for file in testFiles:
            try:
                docs = yaml.loadFile(file)
            except IOError:
                raise "See TESTING for how to set up TestingSuite"
            for doc in docs:
                if doc.has_key('python'):
                    self.verifyOneDoc(doc)
                if doc.has_key('error') and doc['error'].has_key('python'):
                    #if doc.has_key('test'):
                    #    print 'asserting error on ',doc['test']
                    assertError(YamlLoader(doc), doc['error']['python'])

    def verifyOneDoc(self, doc):
        if doc.has_key('python_setup'):
            exec(doc['python_setup'])
        data = eval(doc['python'])
        #if doc.has_key('test'):
        #    print 'asserting equals on ',doc['test']
        assertEquals(list(yaml.load(doc['yaml'])), data)
        if not doc.has_key('NO_ROUND_TRIP'):
            self.assertRoundTrip(data)

    def assertRoundTrip(self, data):
        # XXX - A5 won't round trip when enclosed by 
        # an array...need to investigate
        for item in data:
            assertEquals(item, 
                yaml.load(yaml.dump(item)).next(), 'roundtrip')


if __name__ == '__main__':
    import unittest
    unittest.main()
