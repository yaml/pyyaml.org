import YamlTest
import yaml
from test import assertEquals

class Test(YamlTest.YamlTest):
    def testYpath(self):
        try:    
            for test in yaml.loadFile("./yaml/tests/TestingSuite/ypath.yml"):
                if not test.has_key('ignore'):
                    expr = test['ypath']
                    pth = yaml.ypath(expr,cntx=1)
                    lst = [] 
                    for x in pth.apply(test['data']):
                        lst.append(str(x))
                    exp = test['expected']
                    if test.has_key('unordered'):
                       lst.sort()
                       exp.sort()
                    assertEquals(lst,exp,expr + " => " + str(pth))
        except NotImplementedError: 
            assert()
if __name__ == '__main__':
    import unittest
    unittest.main()
