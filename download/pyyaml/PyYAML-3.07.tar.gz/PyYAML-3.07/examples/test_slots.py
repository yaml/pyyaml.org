
import pickle

class C(object):

    __slots__ = ('a', 'b', 'c')

    def __init__(self, a, b, c):
        self.a = a
        self.b = b
        self.c = c

c = C(1,2,3)

print pickle.dumps(c)

