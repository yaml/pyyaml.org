import yaml

class Test(yaml.YAMLObject):
   yaml_tag = u'!Test'

   def __init__(self, name):
       self.name = name

   def __repr__(self):
       return "%s(name=%r)" % (self.__class__.__name__, self.name)


test = yaml.load("""
--- !Test
name: my name is Test
""")

print test
