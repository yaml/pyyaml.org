
from yaml import *

class MyLoader(CLoader):
    pass

class MyDumper(CDumper):
    pass

add_path_resolver(u'!root', [],
        Loader=MyLoader, Dumper=MyDumper)

add_path_resolver(u'!root/scalar', [], str,
        Loader=MyLoader, Dumper=MyDumper)

add_path_resolver(u'!root/key11/key12/*', [u'key11', u'key12'],
        Loader=MyLoader, Dumper=MyDumper)

add_path_resolver(u'!root/key21/1/*', [u'key21', 1],
        Loader=MyLoader, Dumper=MyDumper)

add_path_resolver(u'!root/key31/*/*/key14/map', [u'key31', None, None, u'key14'], dict,
        Loader=MyLoader, Dumper=MyDumper)

data = open('resolver.path', 'r').read()

#print MyDumper.yaml_path_resolvers

output = serialize_all(compose_all(data), Dumper=MyDumper)

print output
