#!/usr/bin/python

import yaml

class Test(yaml.YAMLObject):
    yaml_tag = u'!Test'

    def __init__(self, init_attr):
        self.init_attr = init_attr

    def __setstate__(self, state):
        print state

    def __repr__(self):
        return "%s(init_attr=%r,yaml_attr=%r)" % (self.__class__.__name__,
        self.init_attr,self.yaml_attr)


test = yaml.load("""
--- !Test
yaml_attr: attribute from yaml
""")

test.__init__('attribute from init')
